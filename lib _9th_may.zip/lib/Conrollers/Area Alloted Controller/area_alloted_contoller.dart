import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';

import '../../API Integration/API URL endpoints/api_endpoints.dart';
import '../../Models/Vendor/Area Alloted Model/get_area_alloted_model.dart';
import '../../Models/Vendor/Area Alloted Model/get_order_list_model.dart';
import '../../Utils/Components/custom_sanckbar.dart';
import '../../Utils/Components/dataStroage_database.dart';

class AreaAllotedController extends GetxController{


  /// get Area Alloted Api
  GetAreaAllotedModel? getAreaAllotedModel;
  Future<GetAreaAllotedModel?> getAreaAllotedApi(BuildContext context,page,limit,searchText,vendorId) async {

    String  userToken = await SharedPref().getToken();
    String token = userToken;
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    var dio = Dio();
    (dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () =>
    HttpClient()
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.areaAlloted}?page=$page&limit=$limit&searchText=$searchText&requestedVendorId=${vendorId}',
        options: Options(
          headers: headers,
        ),
      );
      print(response.requestOptions.uri);
      if (response.statusCode == 200) {
        var result = response.data;

        getAreaAllotedModel = GetAreaAllotedModel.fromJson(result);
        update();
        if(result['isTokenExpired']??false){
          CustomSnackBar.mySnackBar(
              context, "${result['message']}");
        }
        update();
        //   CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getAreaAllotedModel;
  }

  /// get Area Alloted Api
  GetOrderModel? getOrderModel;
  Future<GetOrderModel?> getOrderListApi(BuildContext context,page,limit,searchText,vendorId) async {

    String  userToken = await SharedPref().getToken();
    String token = userToken;
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    var dio = Dio();
    (dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () =>
    HttpClient()
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.getOrderList}?page=$page&limit=$limit&searchText=$searchText&requestedVendorId=${vendorId}',
        options: Options(
          headers: headers,
        ),
      );
      print(response.requestOptions.uri);
      if (response.statusCode == 200) {
        var result = response.data;

        getOrderModel = GetOrderModel.fromJson(result);
        update();
        if(result['isTokenExpired']??false){
          CustomSnackBar.mySnackBar(
              context, "${result['message']}");
        }
        update();
        //   CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getOrderModel;
  }


}