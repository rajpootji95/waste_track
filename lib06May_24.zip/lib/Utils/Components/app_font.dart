class AppFont {
  static const String poppinsBold = 'Poppins-bold';
  static const String poppinsSemiBold = 'Poppins-semiBold';
  static const String poppinsRegular = 'Poppins-Regular';
  static const String poppinsMedium = 'Poppins-Medium';
  static const String poppinsLight = 'Poppins-Light';
}
