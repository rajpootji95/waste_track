class WithdrawItemModel {
  final String name;
  final String imageUrl;
  final String number;

  WithdrawItemModel(
      {required this.name, required this.imageUrl, required this.number});
}
