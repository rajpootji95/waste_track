enum UserType {
  admin,
  subAdmin,
  vendor,
  vendorStaff,
  wasteManagementAgency,
  wasteManagementStaff,
  stateGovernmentAgency
}
