class Endpoints {
  Endpoints._();

  //baseURL
  static const String baseUrl = "http://matchitsports.com:4000/api/";

  //imageURL
  static const String imageUrl = "http://162.0.208.12:4000/uploads/";

  // Auth
  static const String login = "auth/login";
  static const String register = "auth/register";
  static const String role = "roles";
  static const String forgot = "auth/forget-password";
  static const String profile = "auth/get-profile";
  static const String update = "auth/update-profile";
  static const String update_Password = "auth/update-password-with-current";

  //SubAdmin
  static const String subAdmin = "subadmin/add-subadmin";
  static const String getSubAdmin = "subadmin/subadmin-listing";
  static const String deleteSubAdmin = "subadmin/delete-subadmin";
  static const String updateSubAdmin = "subadmin/update-single-subadmin";

  //EcoBlueSubAdmin
  static const String ecoBlueSubAdmin = "ecoblue/add-ecoblue-admin";
  static const String getEcoBlueSubAdmin = "ecoblue/ecoblue-admin-listing";
  static const String deleteEcoBlueSubAdmin = "ecoblue/delete-ecoblue-admin";
  static const String updateEcoBlueSubAdmin = "ecoblue/update-single-ecoblue";

  //Waste Management Agency
  static const String addWasteAgency = "wasteagency/add-wasteagency";
   static const String getWasteAgency = "wasteagency/get-single-wasteagency";
  static const String deleteWasteAgency = "wasteagency/delete-wasteagency";
  static const String updateProfilePicWasteAgency = "wasteagency/update-wasteagency-profile";
 static const String updateWasteAgency = "wasteagency/update-single-wasteagency";


  //Waste Management Staff
  static const String addWasteStaff = "wasteagency/add-wasteagency-staff";
  static const String getWasteStaff = "wasteagency/wasteagency-staff-listing";
  // static const String deleteWasteAgency = "wasteagency/delete-wasteagency";
  // static const String updateProfilePicWasteAgency = "wasteagency/update-wasteagency-profile";
  // static const String updateWasteAgency = "wasteagency/update-single-wasteagency";


  //StateGovernment Agency
  static const String addStateGovernmentAgency = "stategovtagency/add-stategovtagency";
  static const String getStateGovernmentAgency = "stategovtagency/get-single-stategovtagency";
  static const String deleteStateGovernmentAgency = "stategovtagency/delete-stategovtagency";
  static const String updateStateGovernmentAgency = "stategovtagency/update-single-stategovtagency";
 static const String updateProfilePicStateGovernmentAgency = "stategovtagency/update-stategovtagency-profile";


  //Enforcement Team
  static const String addEnforcement = "enforcementteam/add-enforcementteam";
  static const String getEnforcement = "enforcementteam/get-single-enforcementteam";
   static const String deleteEnforcement = "enforcementteam/delete-enforcementteam";
  static const String updateEnforcement = "enforcementteam/update-single-enforcementteam";
   static const String updateProfileEnforcement = "enforcementteam/update-enforcementteam-profile";

   //Vendor End Points
  static const String searchArea =  'area/search-area';
  static const String addVendor =  'vendor/add-vendor';
  static const String getVendors =  'vendor/vendor-listing';
  static const String UpdateSingleVendor =  'vendor/update-single-vendor';
  static const String deleteVendor =  'vendor/delete-vendor';
  static const String getSingleVendor =  'vendor/get-single-vendor';


  //Vendor Staff End Points
  static const String addVendorStaff =  'vendor/add-vendor-staff';
   static const String getVendorStaff =  'vendor/vendor-staff-listing';
  static const String updateVendorStaff =  'vendor/update-single-vendor-staff';
  static const String deleteVendorStaff =  'vendor/delete-vendor-staff';

//Nylon Generation

  static const String nylonGeneration =  'nylon/nylon-price-qty';
  static const String nylonGenerationPrice =  'nylon/update-nylon-price';
  static const String nylonGenerationQuantity =  'nylon/generate-nylon-rolls';
  static const String getNylonDetails =  'nylon/nylon-batch-listing';
  static const String getNylonBatchDelete =  'nylon/delete-nylon-batch';


  // receiveTimeout
  static const Duration receiveTimeout =
      Duration(milliseconds: 15000); // 15000;

  // connectTimeout
  static const Duration connectionTimeout =
      Duration(milliseconds: 15000); //15000;
}

