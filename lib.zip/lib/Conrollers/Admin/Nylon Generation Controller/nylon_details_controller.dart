


import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide Response;


import 'package:waste_track/API%20Integration/API%20URL%20endpoints/api_endpoints.dart';
import 'package:waste_track/Conrollers/Admin/User%20Management%20Controller/user_management_controller.dart';
import 'package:waste_track/Utils/Components/custom_sanckbar.dart';
import 'package:waste_track/Utils/colors/app_colors.dart';

import '../../../API Integration/app_base_controller.dart';
import '../../../Models/Nylon Generation Model/Nylon Details Model/nylon_details_model.dart';
import '../../../Utils/Components/dataStroage_database.dart';

class NylonDetailsController extends AppBaseController {
  String? vendorId;
  final BuildContext context; // Receive context in the constructor

  NylonDetailsController({required this.context}); // Constructor
  bool isLoading = false;
  bool isGeneratedDetails = true;

  @override
  Future<void> onInit() async {
    super.onInit();
    await getNylonDetailsApi(context,"0","1","10","");
     declareNylonDetailsVisibilityController();
  }

 late final NylonManagementDetailsVisibilityController nylonDetailsVisibilityController;

  declareNylonDetailsVisibilityController(){
    debugPrint("total items ${getNylonDetailsGeneratedModel?.pagination?.totalItems}");
     nylonDetailsVisibilityController = Get.put(
         NylonManagementDetailsVisibilityController(
             List.generate(getNylonDetailsGeneratedModel?.pagination?.totalItems??1, (index) => false).obs
         ));
  }

  showLoader(){
    return showDialog(context: context,
        builder: (_){
      return CupertinoActivityIndicator();
        });
  }

  //getNylonDetailsApi
  GetNylonDetailsModel? getNylonDetailsGeneratedModel;
  GetNylonDetailsModel? getNylonDetailsAssignedModel;
  Future<GetNylonDetailsModel?> getNylonDetailsApi(BuildContext context,isAssigned,page,limit,searchText) async {
    debugPrint("status $isAssigned");
    String  userToken = await SharedPref().getToken();
    String token = userToken;
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    Dio dio = Dio();
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.getNylonDetails}?is_assigned=$isAssigned&page=$page&limit=$limit&searchText=$searchText',
        options: Options(
          headers: headers,
        ),
      );
      if (response.statusCode == 200) {
        var result = response.data;
        var finalResult = GetNylonDetailsModel.fromJson(result);

        if(isGeneratedDetails){
           // debugPrint("generated");
          getNylonDetailsGeneratedModel = finalResult;
        }
        else{
          getNylonDetailsAssignedModel = finalResult;
        }


        if(limit == "10"){
          CustomSnackBar.mySnackBar(
              context, "${getNylonDetailsGeneratedModel!.message}");
        }
        update();
        //   CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getNylonDetailsGeneratedModel;
  }

  //Get Delete Nylon Batch
  Future<void> getNylonBatchDeleteApi(batchId) async {
    showLoader();
    String  userToken = await SharedPref().getToken();
    String token = userToken;
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    Dio dio = Dio();
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.getNylonBatchDelete}?batchId=$batchId',
        options: Options(
          headers: headers,
        ),
      );
      if (response.statusCode == 200) {
        var result = response.data;
        debugPrint("result ===> $result");
        Navigator.pop(context);
        if(result['status']){
          showDeleteSuccessDialog();
        }
        update();
        //   CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        Navigator.pop(context);
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      Navigator.pop(context);
      print('Error: $error');
    }
  }
  showDeleteSuccessDialog(){
    return showDialog(
      context:
      context,
      builder:
          (BuildContext
      context) {
        Future.delayed(
            Duration(
                milliseconds: 800),
                () {
                  getNylonDetailsApi(context, "0", "1", "10", "").then(
                          (value) {
                        Navigator.pop(context);
                      });
                });

        return CupertinoAlertDialog(
          title: Row(
            children: [
              Container(
                padding:
                EdgeInsets.all(10),
                decoration:
                BoxDecoration(
                  borderRadius:
                  BorderRadius.circular(30),
                  color:
                  AppColor.green,
                ),
                child:
                Icon(
                  Icons.done,
                  color:
                  Colors.white,
                ),
              ),
              Flexible(
                child:
                Text(
                  " User Deleted Successfully",
                  style:
                  TextStyle(fontSize: 15, color: AppColor.green),
                ),
              ),
            ],
          ), // show pop-up
        );
      },
    );
  }


  // downLoadFile(fileUrl,id){
  //   FileDownloader.downloadFile(
  //       url: "$fileUrl",
  //       name: "waste_track/",//(optional)
  //       onProgress: (String? fileName, double progress) {
  //         print('FILE fileName HAS PROGRESS $progress');
  //       },
  //       onDownloadCompleted: (String path) {
  //         print('FILE DOWNLOADED TO PATH: $path');
  //       },
  //       onDownloadError: (String error) {
  //         print('DOWNLOAD ERROR: $error');
  //       });
  // }


  // Future<void> _downloadImage(String imageUrl) async {
  //   try {
  //     // Download image
  //     var imageId = await ImageDownloader.downloadImage(imageUrl);
  //
  //     if (imageId != null) {
  //       // Image downloaded successfully
  //       print("Image downloaded with id: $imageId");
  //     } else {
  //       // Error occurred during download
  //       print("Failed to download image");
  //     }
  //   } catch (error) {
  //     print("Error while downloading image: $error");
  //   }
  // }
}