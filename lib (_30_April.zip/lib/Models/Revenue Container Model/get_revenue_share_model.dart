class GetRevenueShareModel {
  GetRevenueShareModel({
     this.status,
     this.message,
     this.data,
  });

   bool? status;
   String? message;
   List<RevenueList>? data;

  factory GetRevenueShareModel.fromJson(Map<String, dynamic> json){
    return GetRevenueShareModel(
      status: json["status"],
      message: json["message"],
      data: json["data"] == null ? [] : List<RevenueList>.from(json["data"]!.map((x) => RevenueList.fromJson(x))),
    );
  }

}

class RevenueList {
  RevenueList({
     this.id,
     this.companyName,
     this.sharingPercentage,
     this.roleId,
  });

   String? id;
   String? companyName;
   int? sharingPercentage;
   String? roleId;

  factory RevenueList.fromJson(Map<String, dynamic> json){
    return RevenueList(
      id: json["_id"],
      companyName: json["companyName"],
      sharingPercentage: json["sharingPercentage"],
      roleId: json["roleId"],
    );
  }

}
