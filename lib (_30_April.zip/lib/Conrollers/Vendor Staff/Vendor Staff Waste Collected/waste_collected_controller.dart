


import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart' hide Response;
import 'package:waste_track/API%20Integration/API%20URL%20endpoints/api_endpoints.dart';
import 'package:waste_track/Utils/Components/dataStroage_database.dart';

import '../../../API Integration/app_base_controller.dart';
import '../../../Models/Nylon Generation Model/Get Nylon Model/get_nylon_model.dart';
import '../../../Models/Vendor Staff/Vendor Staff Waste Collected Model/get_vendor_staff_waste_collected_model.dart';
import '../../../Models/Vendor Staff/Vendor Staff Waste Collected Model/get_waste_collected_model.dart';
import '../../../Utils/Components/custom_sanckbar.dart';


class WasteCollectedController extends AppBaseController {
  String? vendorId;
  final BuildContext context; // Receive context in the constructor

  WasteCollectedController({required this.context}); // Constructor
  bool isLoading = false;
  bool isGeneratedDetails = true;
  bool isLoadingQuantity = false;
  String? subAdmin;

  @override
  Future<void> onInit() async {
    super.onInit();
    getVendorStaffCollectionApi(context,"1","10","");
   await getWasteCollectionApi(context,"1","","");
  }

  /// get Vendor Staff Collection Api
  GetVendorStaffCollectionListModel? getVendorStaffCollectionListModel;
  Future<GetVendorStaffCollectionListModel?> getVendorStaffCollectionApi(context,page,limit,searchText) async {
    var userToken = await SharedPref().getToken();
    var token = "${userToken}";
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    Dio dio = Dio();
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.getCollectionListApi}?page=$page&limit=$limit&searchText=$searchText',
        options: Options(
          headers: headers,
        ),
      );
      if (response.statusCode == 200) {
        var result = response.data;
        var finalResult = GetVendorStaffCollectionListModel.fromJson(result);
        getVendorStaffCollectionListModel = finalResult;
        update();
        CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getVendorStaffCollectionListModel;
  }


  /// get waste collection Api
  GetWasteCollectionListModel? getWasteCollectionListModel;
  Future<GetWasteCollectionListModel?> getWasteCollectionApi(context,page,limit,searchText) async {
   debugPrint("called$searchText");
    var userToken = await SharedPref().getToken();
    var token = "${userToken}";
    var headers = {
      'Authorization': 'Bearer $token', // Assuming your token type is 'Bearer'
    };
    Dio dio = Dio();
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.getWasteCollectionListApi}?page=$page&limit=$limit&searchText=$searchText',
        options: Options(
          headers: headers,
        ),
      );
      if (response.statusCode == 200) {
        var result = response.data;
        var finalResult = GetWasteCollectionListModel.fromJson(result);

        getWasteCollectionListModel = finalResult;
        update();
        CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getWasteCollectionListModel;
  }


}