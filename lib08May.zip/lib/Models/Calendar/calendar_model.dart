class CalenderModel {
  String dateVal;
  String day;

  CalenderModel({
    required this.dateVal,
    required this.day,
  });
}
