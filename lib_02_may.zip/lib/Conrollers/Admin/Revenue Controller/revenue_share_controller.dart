

import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:waste_track/API%20Integration/API%20URL%20endpoints/api_endpoints.dart';
import '../../../API Integration/app_base_controller.dart';
import '../../../Models/Revenue Container Model/get_revenue_share_model.dart';
import '../../../Utils/Components/custom_sanckbar.dart';
import '../../../Utils/Components/dataStroage_database.dart';
import '../../../Utils/colors/app_colors.dart';

class RevenueController extends AppBaseController {
  final BuildContext context;
  RevenueController({required this.context}); // Constructor
  bool isLoading = false;

  @override
  Future<void> onInit() async {
    super.onInit();
    getRevenueShareApi(context);

  }

  /// getRevenueApi
  ///

  List<TextEditingController> parentageControllers = [];
  addControllers(){
    if(getRevenueShareModel?.data != null){
      for (int i = 0; i < getRevenueShareModel!.data!.length; i++) {
        parentageControllers.add(TextEditingController());
      }
    }
  }

  GetRevenueShareModel? getRevenueShareModel;
  Future<GetRevenueShareModel?> getRevenueShareApi(BuildContext context,) async {
    var userToken = await SharedPref().getToken();
    var token = "${userToken}";
    var headers = {
      'Authorization': 'Bearer $token',
    };
    print("headers: ${headers}");
    Dio dio = Dio();
    try {
      Response response = await dio.get(
        '${Endpoints.baseUrl}${Endpoints.revenueShareList}',
        options: Options(
          headers: headers,
        ),
      );
      debugPrint("this response${response.statusCode.toString()}");
      if (response.statusCode == 200) {
        var result = response.data;
        var finalResult = GetRevenueShareModel.fromJson(result);
        getRevenueShareModel = finalResult;
        addControllers();
        debugPrint("message ${getRevenueShareModel!.message}");
        update();
        CustomSnackBar.mySnackBar(context, "${finalResult.message}");
      } else {
        print('Error: ${response.statusCode}');
      }
    } catch (error) {
      print('Error: $error');
    }
    return getRevenueShareModel;
  }

  /// updateRevenueShareApi
  Future<void> updateRevenueShareApi() async {
    if (getRevenueShareModel?.data != null && getRevenueShareModel!.data.isNotEmpty) {
      for (int i = 0; i < parentageControllers.length; i++) {
        String percentage = parentageControllers[i].text;
        if (percentage.isNotEmpty) {
          getRevenueShareModel!.data[i].sharingPercentage = int.parse(percentage);
        }
      }
    } else {
      print('Error: getRevenueShareModel?.data is null or empty');
      return;
    }
    isLoading = true;
    var data = {
      "revenueItems": getRevenueShareModel!.data!.map((item) => {
        "_id": item.id,
        "companyName": item.companyName,
        "sharingPercentage": item.sharingPercentage,
        "roleId": item.roleId
      }).toList()
    };
    var userToken = await SharedPref().getToken();
    update();
    var token = "${userToken}";
    var headers = {
      'Authorization': 'Bearer $token',
    };

    Dio dio = Dio();
    try {
      Response<dynamic> response = await dio.post(
        '${Endpoints.baseUrl}${Endpoints.updateRevenueShareList}',
        options: Options(
          headers: headers,
        ),
        data: data,
      );
      debugPrint("response: ${response.data}");

      if (response.statusCode == 200) {
        var responseData = response.data;
        var message = responseData['message'];
        isLoading = false;
        update();

        if (responseData['error'] == null) {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              Future.delayed(Duration(milliseconds: 1000), () {
                Navigator.pop(context);
              });

              return CupertinoAlertDialog(
                title: Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        color: AppColor.green,
                      ),
                      child: Icon(
                        Icons.done,
                        color: Colors.white,
                      ),
                    ),
                    Flexible(
                      child: Text(
                        "${message}",
                        style: TextStyle(fontSize: 15, color: AppColor.green),
                      ),
                    ),
                  ],
                ), // show pop-up
              );
            },
          );
        }
      } else {
        isLoading = false;
        update();
        print('Failed with status code: ${response.statusCode}');
      }
    } catch (error) {
      isLoading = false;
      update();
      print('Error: $error');
    }
  }








}