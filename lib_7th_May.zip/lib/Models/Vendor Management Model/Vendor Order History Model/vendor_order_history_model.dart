class OrderHistoryItemModel {
  final String name;
  final String imageUrl;
  final String number;

  OrderHistoryItemModel(
      {required this.name, required this.imageUrl, required this.number});
}
