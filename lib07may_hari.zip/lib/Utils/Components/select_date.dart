// import 'package:flutter/cupertino.dart';

// import '../colors/app_colors.dart';

// Widget selectDateView({required String chooseDate}) {
//   return Container(
//     padding: EdgeInsets.symmetric(horizontal: 15),
//     height: 40,
//     decoration: BoxDecoration(
//       gradient: AppColor.gradient,
//       borderRadius: BorderRadius.circular(12),
//     ),
//     child: Row(
//       mainAxisAlignment: MainAxisAlignment.spaceBetween,
//       children: [
//         Text(
//           chooseDate.isEmpty ? "select date" : "${chooseDate}".split(' ')[0],
//           style: const TextStyle(color: AppColor.black),
//         ),
//         // SvgPicture.asset(AppImages.calendarIcon)
//       ],
//     ),
//   );
// }
